<template>

  <div class="posts">
  
    <h3>vote for poll</h3>
    <!--span><b>{{ response }}</b></span><br /-->
    <form v-on:submit="voteElection">
      <input type="text" v-model="electionId" placeholder="Enter election key">
      <br>
       <br>
      <input type="submit" class = "btn btn-block mybtn btn-primary tx-tfm" value="vote">
      <br>
      <br>
      <span v-if="votingReponse">
        <b>{{ votingReponse.data }}</b>
      </span>
      <br>
    </form>
   <br>
    <h3>My Polls</h3>
   <b-table class="table" id="table" striped hover :items="rows"></b-table> 
    <br>
    <vue-instant-loading-spinner id='loader' ref="Spinner"></vue-instant-loading-spinner>
  </div>
 
</template>

<script>
import PostsService from "@/services/apiService";
import VueInstantLoadingSpinner from "vue-instant-loading-spinner/src/components/VueInstantLoadingSpinner.vue";

export default {
  name: "Dashboard",
  data() {
    return {
      rows:[],
     
      electionId:"",
      votingReponse: {
        data: ""
      }
    };
  },
  components: {
    VueInstantLoadingSpinner
  },
  async updated(){
     if(!this.$cookies.isKey('cookie')){
       this.$router.push('Home');
    }
    else{
       if(!this.$cookies.isKey('ElectionCookie')){
       this.$cookies.remove('ElectionCookie');
    }
    const apiResponse = await PostsService.getAllUsersPolls(
     this.$cookies.get('cookie')
     );
     for( let i=0;i<apiResponse.length;i++){
         let record=apiResponse[i].Record;
         let row={name:record.title,start_date:record.startDate,end_date:record.endDate,number_of_votes:record.voters.length,key:apiResponse[i].Key};
         rows.push(row);
     }
    }
  },
    created: async function(){
    if(!this.$cookies.isKey('cookie')){
       this.$router.push('Home');
    }
    else{
   if(!this.$cookies.isKey('ElectionCookie')){
       this.$cookies.remove('ElectionCookie');
    }
    const apiResponse = await PostsService.getAllUsersPolls(
     this.$cookies.get('cookie')
     );
     let arr=apiResponse.data;
     console.log(arr);
     for( let i=0;i<arr.length;i++){
         let record=arr[i].Record;
         console.log(Object.keys(record.voters).length);
         let row={name:record.name,startDate:record.startDate==""? '-':record.startDate
         ,endDate:record.endDate==""? '-':record.endDate,numOfVotes:Object.keys(record.voters).length,key:arr[i].Key};
         this.rows.push(row);
     } 
    }

},
  methods: {
    async voteElection() {
      await this.runSpinner();
      const apiResponse = await PostsService.validateElectionId(
     this.$cookies.get('cookie'),this.electionId
     );
     if(apiResponse.data){
       this.$cookies.set('ElectionCookie',this.electionId);
      this.$router.push("CastBallot");
     }
     else{
        this.votingReponse.data = 'election with this id doesnt exists';

     }
      await this.hideSpinner();
    },
    async runSpinner() {
      this.$refs.Spinner.show();
    },
    async hideSpinner() {
      this.$refs.Spinner.hide();
    }
  }
};
</script>
<style>

#table{
 margin: 0 auto;
 width: 750px;

}
h3 {
  margin-bottom: 30px;
}

th,
td {
  text-align: left;
  border: 1px solid black;
 
}

th:nth-child(n+2),
td:nth-child(n+2) {
  text-align: center;
}

thead tr:nth-child(2) th {
  font-weight: normal;
}

.VueTables__sort-icon {
  margin-left: 20px;
}

.VueTables__dropdown-pagination {
  margin-left: 20px;
}

.VueTables__highlight {
  background: yellow;
  font-weight: normal;
}

.VueTables__sortable {
  cursor: pointer;
}

.VueTables__date-filter {
  border: 1px solid #ccc;
  padding: 6px;
  border-radius: 4px;
  cursor: pointer;
}

.VueTables__filter-placeholder {
  color: #aaa;
}

.VueTables__list-filter {
  width: 120px;
}

</style>