<template>
  <div class="posts">
    <div class="poll-view" style="padding-top: 50px">
        <div class="poll-view__title">
           <h1> Create new poll</h1>
        </div>
        <br>
        <div class="poll-view__inner">
           <div class="poll-view__title" >
                <input v-model="poll.title" type="text" placeholder="Your title..." style="height: 30px; width: 250px;">
                 
            </div>
            <div class="poll-view__question">
                <input v-model="poll.question" type="text" placeholder="Your Question..." style="height: 30px; width: 250px;">
                 <br>
                 <br>
            </div>
            <div class="poll-view__answers">
                <div v-for="(name, index) in poll.answers" :key="index" class="answer" :style="{zIndex: poll.answers.length - index}">
                    <input :placeholder="'Answer ' + (index + 1)" @focus="createNewInput(index)" v-model="poll.answers[index].name" type="text">
                    <span class="delete" @click="deleteInput(index)"> delete</span>
                     <br>
                     <br>
                </div>
            </div>
          <div class="poll-view__options">
                <label class="checkbox">Choose dates 
                    <input v-model="poll.chooseDates" type="checkbox"  v-on:click="checkbox">
                    <span class="checkmark"></span>
                </label>
            </div>
            <span v-if="chooseDates">
            <div class="pick_date">Start date: <date-pick v-model="start_date"></date-pick>
               </div>
                <br>
                 <div class="pick_date">End date: <date-pick v-model="end_date"></date-pick>
               </div>
            </span>
            <div class="poll-view__submit">
                <button @click="createPoll">Create</button>
            </div>
            <div class="poll-view__info" :class="{'success' : success === true, 'error' : success === false}" v-if="success !== null">
                <div v-if="success === true">Created</div>
                <div v-if="success === false">Error</div>
            </div>
        </div>
        <br>
      <span v-if="response">
      <br>
        <b>{{ response.data }}</b>
      </span>
       <br>
         <vue-instant-loading-spinner id='loader' ref="Spinner"></vue-instant-loading-spinner>
    </div>
    </div>
</template>

<script>

import PostsService from "@/services/apiService";
import VueInstantLoadingSpinner from "vue-instant-loading-spinner/src/components/VueInstantLoadingSpinner.vue";
import DatePick from 'vue-date-pick';
import 'vue-date-pick/dist/vueDatePick.css';

export default {
    name: "CreatePoll",
    data() {
        return {
        response: {
            data: ""
          },
            createdBy:"",
            start_date:"",
            end_date:"",
            poll: {
                title:"",
                question: "",
                answers: [
                    { name: "" },
                    { name: "" },
                    { name: "" },
                    { name: "" }
                ],
            },
            chooseDates: false,
            isValid: false,
            success: null
        };
    },
    components: {
    VueInstantLoadingSpinner,
   DatePick
  },
    mounted () {
        if (this.poll.answers.length == 0) {
            this.poll.answers.push({answer: ""})
        }
    },
   created: async function(){
    if(this.$cookies.isKey('cookie')){
        this.createdBy=this.$cookies.get('cookie');
    }
    else{
         this.$router.push('Home');
    }
   },
    methods: {
        async checkbox(){
            this.chooseDates=!this.chooseDates;
        },
       async createNewInput(index) {
            if (this.poll.answers.length - 1 == index) {
                this.poll.answers.push({ answer: "" });
            }
        },
       async deleteInput(index) {
            if (index > 0 || this.poll.answers.length > 1) {
                this.poll.answers.splice(index, 1);
            }
        },
        async createPoll() {
         this.validate();
          if (this.isValid) {
            await this.runSpinner();

            const apiResponse = await PostsService.createPoll(
            this.poll.title,
            this.poll.question,
            this.start_date,
            this.end_date,
            this.createdBy,
            this.poll.answers );
        if (apiResponse.data.error) {
          this.loginReponse = apiResponse.data.error;
        } else{
          console.log(apiResponse);
           this.response = apiResponse;
        }
           await this.hideSpinner();
          } else {
           let response = 'You need to fill all the fields';
           this.response.data = response1;
           }
        },
       async resetPoll() {
            this.poll.chooseDates = false;
            this.poll.answers = [];
            this.poll.answers.push({answer: ""})
            this.poll.answers.push({answer: ""})
            this.poll.answers.push({answer: ""})
            this.poll.answers.push({answer: ""})
            this.poll.question = ""
            this.isValid = false
        },
       async validate () {
            this.poll.answers = this.poll.answers.filter((answer) => {
                if (answer.name.length > 0) {
                    return answer;
                }
            });
            var count = this.poll.answers.length
            if (count > 1) {
                this.isValid = true;
            } else  {
                this.isValid = false;
            }
        },
         async runSpinner() {
      this.$refs.Spinner.show();
    },
    async hideSpinner() {
      this.$refs.Spinner.hide();
    }
    }
};
</script>
