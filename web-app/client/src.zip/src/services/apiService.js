import Api from '@/services/api'

export default {
  castBallot(electionId, voterId, picked) {
    return Api().post('castBallot', {       
      electionId: electionId,
      voterId: voterId,
      picked: picked
    })
  },
  queryAll() {
    return Api().get('queryAll')
  },
  queryByObjectType() {
    return Api().get('queryByObjectType')
  },
  queryWithQueryString(selected) {
    return Api().post('queryWithQueryString', {
      selected: selected
    }) 
  },
  registerVoter(voterId, firstName, lastName,password,checkPassword) {
    return Api().post('registerUser', {
      voterId: voterId,
      firstName: firstName,
      lastName: lastName,
      password:password,
      checkPassword:checkPassword
      
    }) 
  },
  logInUser(voterId,password) {
    return Api().post('logInUser', {
      voterId: voterId,
      password:password
    }) 
  },
  queryByKey(key) {
    return Api().post('queryByKey', {
      key: key
    }) 
  },
  getAllUsersPolls(key){
    return Api().post('getAllUsersPolls', {
      key: key
    }) 
  },
  getAllVotableItemsForElection(electionId){
    return Api().post('getAllVotableItemsForElection', {
      electionId:electionId
    }) 
  },
  createPoll(title,question,startDate,endDate,createdBy,answers){
    return Api().post('createPoll', {
      name: title,
      question: question,
      startDate: startDate,
      endDate:endDate,
      createdBy:createdBy,
      votableItems:answers
      
    }) 

  },
  validateElectionId(key,electionId){
    return Api().post('validateElectionId', {
      key: key,
      electionId:electionId
    }) 
  }

}